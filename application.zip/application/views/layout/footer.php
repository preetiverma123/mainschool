<footer>
    <div class="pull-right">
        ©2018 School Management Stystem |
    </div>
    <div class="clearfix"></div>
</footer>