<section class="page-title-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12"><h1 class="page-title"><?php echo $this->lang->line('privacy_policy'); ?></h1></div>
        </div>
    </div>
</section>

<section class="content-area">
    <div class="container">

        <div class="row">
            <div class="col-md-12 col-sm-12">
                <?php echo $privacy->page_description; ?>
            </div>         
        </div>
    </div>
</section>